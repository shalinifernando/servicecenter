<?php
	session_start();
  	include('include/dbconn.php');
  	include('include/function.php');
 	
 	if($_SERVER['REQUEST_METHOD']=="POST")
 	{

 		
 		$uname=$_POST['uname'];
 		$password=$_POST['password'];


 		if(!empty($uname)&& !empty($password) && !is_numeric($uname))
 		{
 			$query = "SELECT * FROM admin WHERE email='$uname' limit 1";
 			$result =mysqli_query($con,$query);

 			if($result)
 			{

 			  if($result && mysqli_num_rows($result)>0){
 			  	$user_data = mysqli_fetch_assoc($result);

 			  	if($user_data['password']=== $password){
 			  		$_SESSION['ad_id'] = $user_data['ad_id'];
 			  		
 			  		header("location: production/dashboard.php");
 			  	}
 			  }
 			}
 			
 			echo "please enter valid username password";
 			
 		}
 		else{
 			echo "Please enter valid information";
 		}
	}
 	
?>


<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Milco(PVT)LTD | Login</title>
</head>
<style type="text/css">
	#mainbar{
		width: 400px;
		padding: 4px;
		border-radius: 4px;
		margin: auto;
		margin-top: 100px;
		text-align: center;
		font-weight: bold;
		background-color: white;
		padding-top: 10px;
	}
	#text{
		width: 300px;
		height: 40px;
		border-radius: 4px;
		border: solid 1px #ccc;
		padding: 4px;
		font-size: 14px;

	}
	#btn{
		width: 300px;
		height: 40px;
		border-radius: 4px;
		padding: 4px;
		font-weight: bold;
		border: none;
		background-color: #3c5a99;
		color: white;
		}

</style>
<body style="background-color: #e9ebee; font-family: tohoma;">
	<div id="mainbar">
	<form method="post">
		<h3>Milco Faramer Management System</h3><br>
		<input type="text" placeholder="Enter User Name" id="text" name="uname"><br><br>
		<input type="Password" placeholder="Enter Password" id="text" name="password"><br><br>
		<input type="submit" value="Login" id="btn"><br><br>
		<a href="signup.php">signup</a>
	</form>
	</div>

</body>
</html>