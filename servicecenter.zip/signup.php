<?php
	session_start();
  	include('include/dbconn.php');
  	include('include/function.php');
 	
 	if($_SERVER['REQUEST_METHOD']=="POST")
 	{

 		$fname=$_POST['fname'];
 		$lname=$_POST['lname'];
 		$uname=$_POST['uname'];
 		$password=$_POST['password'];


 		if(!empty($fname) && !empty($lname) && !empty($uname)&& !empty($password) && !is_numeric($uname))
 		{
 			$query = "insert into admin(fname,lastname,username,password,utid) values('$fname','$lname','$uname','$password','1')";
 			mysqli_query($con,$query);
 			header("location: index.php");
 			die;
 			echo "data save successfuly";
 		}
 		else{
 			echo "Please enter valid information";
 		}
 	}
?> 


<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Mybook | Signup</title>
	</head>
	<style >
	
		#signup{
			background-color: #42b72a;
			width: 70px;
			text-align: center;
			border-radius: 4px;
			padding: 4px;
			float: right;

		}
		#bar2{
			background-color: white;
			width: 800px;			
			margin: auto;
			margin-top: 50px;
			text-align: center;
			padding: 10px;
			padding-top: 50px;
			font-weight: bold;

		}
		#text{
			width: 300px;
			height: 40px;
			border-radius: 4px;
			border: solid 1px #ccc;
			padding: 4px;
			font-size: 14px;

		}
		#submit{
			width: 300px;
			height: 40px;
			border-radius: 4px;
			padding: 4px;
			font-weight: bold;
			border: none;
			background-color: #3c5a99;
			color: white;
		}
	</style>
	<body style="background-color: #e9ebee; font-family: tohoma;">
	<form method="post">
		<div id="bar2">
			<h2>Signup Milco(PVT)LTD</h2>
			<br>
			<input name="fname" type="text" id="text" placeholder="First Name"><br><br>
			<input name="lname" type="text" id="text" placeholder="Last Name"><br><br>
			
			<input name="uname" type="text" id="text" placeholder="User Name"><br><br>
			<input name="password" type="password" id="text" placeholder="Password"><br><br>
			<input type="repassword" id="text" placeholder="Retype Password"><br><br>
			<input type="submit" id="submit" value="Sign Up">			
		</div>
	</form>
	</body>
</html>