<?php 

session_start();

if(isset($_SESSION['aid']))
{
	unset($_SESSION['aid']);
}

header('Location:index.php');
die;