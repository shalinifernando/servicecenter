<?php 
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $dbname = "my_garage";


 if(!$con = mysqli_connect($dbhost, $dbuser, $dbpass ,$dbname) ){
    die('Unabale to connect to the database');
 } 
