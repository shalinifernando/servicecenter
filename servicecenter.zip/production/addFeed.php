<?php
	session_start();	
	include '../include/dbconn.php';
	include('../include/function.php');
	$user_data = checkLogin($con);

	if(isset($_POST['save_btn'])){
	
	$cnumber = mysqli_real_escape_string($con,$_POST['cnumber']); 
	$fitem = mysqli_real_escape_string($con,$_POST['fitem']);
	$quality = mysqli_real_escape_string($con,$_POST['quality']);
	$remark = mysqli_real_escape_string($con,$_POST['remark']);
	$dob = mysqli_real_escape_string($con,$_POST['dob']);	
	$time = mysqli_real_escape_string($con,$_POST['time']);	
	$aid = mysqli_real_escape_string($con,$_SESSION['aid']);
		
		$sql = "SELECT * FROM feed WHERE regno = '$cnumber'";
		$query = $con->query($sql);
		if($query->num_rows < 1){
			$_SESSION['msg'] = 'Cow not found';
		}

		else{		
			$row = $query->fetch_assoc();
			$cownum= $row['regno'];
			$sql ="insert into 
					 feed
					 (regno,date,remark,food,quality,feedtime,aid) 
	 				 values
					 ('$cnumber','$dob','$remark','$fitem','$quality','$time','$aid')";
			if($con->query($sql)){
				$_SESSION['msg'] = 'vaccince registration successfully';
				header('location: feed.php');
				echo mysqli_error($con);
			}
			else{
				$_SESSION['msg'] = 'unscucessfully';
			}
		}
	}	
	else{
		$_SESSION['msg'] = 'Fill up add form first';
	}
	
//click edit vaccine
if(isset($_GET['regno']))
		{
			$regno = mysqli_real_escape_string($con,$_GET['regno']);
		   
		    $query = " SELECT * FROM feed WHERE feedid = '$regno'";
		    $query_run = mysqli_query($con, $query);

		    if(mysqli_num_rows($query_run) == 1)
		    {
		        $farmer = mysqli_fetch_array($query_run);

		        $res = [
		            'status' => 200,
		            'message' => 'Cow Fetch Successfully by id',
		            'data' => $farmer
		        ];
		        echo json_encode($res);
		        return;
		    }
		    else
		    {
		        $res = [
		            'status' => 404,
		            'message' => 'Cow Id Not Found'
		        ];
		        echo json_encode($res);
		        return;
		    }
		}
//update vaccine

if(isset($_POST['update_cow']))
{
	$cnum = mysqli_real_escape_string($con,$_POST['cnum']);
	$feedid = mysqli_real_escape_string($con,$_POST['feedid']); 	
	$dob = mysqli_real_escape_string($con,$_POST['dob']);	
	$remark = mysqli_real_escape_string($con,$_POST['remark']);		
	$food = mysqli_real_escape_string($con,$_POST['food']);		
	$quality = mysqli_real_escape_string($con,$_POST['quality']);		
	$ftime = mysqli_real_escape_string($con,$_POST['ftime']);
	$aid = mysqli_real_escape_string($con,$_SESSION['aid']);


$sql = "SELECT * FROM feed WHERE regno = '$cnum'";
		$query = $con->query($sql);
		if($query->num_rows < 1){
			$_SESSION['msg'] = 'Cow not found';
		}
		else{		
			$row = $query->fetch_assoc();
			$sql ="UPDATE feed
				  SET regno='$cnum',date='$dob',remark='$remark',aid='$aid' , food='$food' , quality='$quality' , feedtime='$ftime' WHERE feedid='$feedid'";
				  echo $sql;
			
			if($con->query($sql)){
				$_SESSION['msg'] = 'cow update successfully';
				header('location: feed.php');

				echo mysqli_error($con);
			}
			else{
				$_SESSION['msg'] = 'cannot update';
			}
		}
	}

//delete vacacine
if(isset($_POST['delete_cow']))
{
	$cow_id = mysqli_real_escape_string($con,$_POST['cow_id']);

	$query = "DELETE FROM feed WHERE feedid='$cow_id'";	
	$query_run = mysqli_query($con,$query);
	if($query_run)
    {
        $res = [
            'status' => 200,
            'message' => 'Student Deleted Successfully'
        ];
        echo json_encode($res);
        return;
    }
    else
    {
        $res = [
            'status' => 500,
            'message' => 'Student Not Deleted'
        ];
        echo json_encode($res);
        return;
    }
}