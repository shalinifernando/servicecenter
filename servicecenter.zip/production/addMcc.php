<?php 
include '../include/dbconn.php';


$scode = $_POST['scode'];
$mcccode = $_POST['mcccode'];
$mccname = $_POST['mccname'];
$roffice = $_POST['roffice'];


$query = "insert into mcc(name,shortcode,mcccode,regid) values('$mccname','$scode','$mcccode','$roffice')";
mysqli_query($con,$query);
echo mysqli_error($con);
header('location: center.php');
