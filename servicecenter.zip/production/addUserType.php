<?php 
	session_start();	
	include '../include/dbconn.php';
	include('../include/function.php');
	$user_data = checkLogin($con);
//create user
if(isset($_POST['uAsave'])){	
    $usertype = mysqli_real_escape_string($con,$_POST['com_usertype']);
    $email = mysqli_real_escape_string($con,$_POST['txt_email']);
    $password = mysqli_real_escape_string($con,$_POST['txt_repassword']);
  
   
	$sql = "SELECT email FROM admin WHERE email = '$email'";
	$query = $con->query($sql);
		if($query->num_rows < 1){		

			$sql ="INSERT INTO admin(email,password,sc_usertype_utype_id) 
				   VALUES('$email','$password','$usertype')";
				echo mysqli_error($con); 
				echo $sql;
			
			if($con->query($sql)){
				echo $sql;				
				header('location: useraccount.php');
				echo mysqli_error($con);
				$_SESSION['msg'] = 'save successfuly';
								
					echo mysqli_error($con);
			}
			else{
				$_SESSION['msg'] = 'unscucessfully';
			}
			}
		else{		
			$_SESSION['msg'] = 'Famer not found';
		}
$_SESSION['msg'] = 'save successfuly';
	
	}	
	else{
		$_SESSION['msg'] = 'Fill up add form first';
	}
// //save user type
// if(isset($_POST['utsave'])){	
//     $usertype = mysqli_real_escape_string($con,$_POST['txt_usertype']); 	
// 	// $aid = mysqli_real_escape_string($con,$_SESSION['aid']);

// 	$sql = "SELECT user_type FROM usertype WHERE user_type = '$usertype'";
// 	$query = $con->query($sql);
// 		if($query->num_rows < 1){		

// 			$sql ="INSERT INTO usertype(user_type) 
// 				   VALUES('$usertype')";

// 			echo $sql;
// 			if($con->query($sql)){
// 				echo $sql;				
// 				header('location: usertype.php');
// 				echo mysqli_error($con);
// 				$_SESSION['msg'] = 'save successfuly';
								
// 					echo mysqli_error($con);
// 			}
// 			else{
// 				$_SESSION['msg'] = 'unscucessfully';
// 			}
// 			}
// 		else{		
// 			$_SESSION['msg'] = 'Famer not found';
// 		}
// 	}	
// 	else{
// 		$_SESSION['msg'] = 'Fill up add form first';
// 	}

// 	//click edit user type
if(isset($_GET['ad_id']))
		{
			$ad_id = mysqli_real_escape_string($con,$_GET['ad_id']);
		 
		    $query = 
		    "
		    	SELECT * 
				FROM admin ad,sc_usertype sc
				 where ad.sc_usertype_utype_id = sc.utype_id
				 and ad.ad_id='$ad_id';
		    ";
		    $query_run = mysqli_query($con, $query);

		    if(mysqli_num_rows($query_run) == 1)
		    {
		        $farmer = mysqli_fetch_array($query_run);

		        $res = [
		            'status' => 200,
		            'message' => 'designation Fetch Successfully by id',
		            'data' => $farmer
		        ];
		        echo json_encode($res);
		        return;
		    }
		    else
		    {
		        $res = [
		            'status' => 404,
		            'message' => 'designation id not found'
		        ];
		        echo json_encode($res);
		        return;
		    }
		}


// //update user type
// if(isset($_POST['ustype']))
// {
// 	$usertype = mysqli_real_escape_string($con,$_POST['txt_usertype']);
// 	$usertypeid = mysqli_real_escape_string($con,$_POST['txt_usertypeid']);
	


// 	$query = "UPDATE usertype 
//     		  SET user_type='$usertype'
//               WHERE utid='$usertypeid'";

//               echo $query;
   
// 		mysqli_query($con,$query);
// 		header('location: usertype.php');
	
//}