
<!--edit vaccine -->

<div class="modal fade" id="editmodel" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Edit feed Details</h4>
                   <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">×</span>
                    </button>
          </div>
              <div class="modal-body">
                <form class="form-horizontal" method="POST" action="addFeed.php">
                  <input type="hidden" class="empid" name="id">
                    <div class="form-group">
                     <label for="edit_firstname" class="col-sm-3 control-label">COW NUMBER</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" id="ucownum" name="cnum">
                          <input type="hidden" class="form-control" id="ufeed" name="feedid">
                        </div>
                    </div>
                    <div class="form-group">
                      <label for="edit_lastname" class="col-sm-3 control-label">DATE</label>
                      <div class="col-sm-9">
                        <input type="date" class="form-control" id="udob" name="dob">
                    </div>
                  </div>
                  <div class="form-group">
                      <label for="edit_contact" class="col-sm-3 control-label">REMARK</label>
                      <div class="col-sm-9">
                        <input type="text" class="form-control" id="ureamrk" name="remark">
                      </div>
                  </div>
                  <div class="form-group">
                     <label for="edit_firstname" class="col-sm-3 control-label">FOOD</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" id="ufood" name="food">                        
                        </div>
                   </div>
                    <div class="form-group">
                     <label for="edit_firstname" class="col-sm-3 control-label">QUALITY</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" id="uquality" name="quality">                        
                        </div>
                   </div>
                   <div class="form-group">
                     <label for="edit_firstname" class="col-sm-3 control-label">FEED TIME</label>
                        <div class="col-sm-9">
                          <input type="time" class="form-control" id="uftime" name="ftime">                        
                        </div>
                   </div>
                  
                   
            </div>
                        <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary " name="update_cow">Update </button>
                        </div>
        </div>
      </form>
</div>
</div>
</div>


