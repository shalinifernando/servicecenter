<?php
  session_start();
  include('../include/dbconn.php');
  include('../include/function.php');

  $user_data = checkLogin($con); 
  
?> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Milco(Pvt)Ltd | Home</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
     <script>
window.onload = function() {

var chart = new CanvasJS.Chart("chartContainer", {
    animationEnabled: true,
    title: {
        text: "Monthly Milk Collection"
    },
    data: [{
        type: "line",
        startAngle:1000 ,
        yValueFormatString: "",
        indexLabel: "{label} {y}",
        dataPoints: [
            {y: 1000, label: "Januart"},
            {y: 300, label: "Febuary"},
            {y: 500, label: "Marck"},
            {y: 900, label: "April"},
            {y: 100, label: "May"},
            {y: 1000, label: "June"},
            {y: 2000, label: "July"},
            {y: 4000, label: "August"},
            {y: 6000, label: "September"},
            {y: 8000, label: "October"},
            {y: 9000, label: "November"},
            {y: 13000, label: "December"},
        ]
    }]
});
chart.render();

}
</script>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="dashboard.php" class="site_title"><i class="fa fa-paw"></i> <span>Milco  Dairy Farm</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
             <?php include('../include/menu.php'); ?>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
             <?php include('../include/slider.php'); ?>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
          
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <?php include('../include/navigation.php'); ?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="row" style="display: inline-block;">
          <div class="tile_count">
            <div class="col-md-3  tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Total Farmers</span>
              <div class="count">
                
                <?php 
                   $query = "SELECT fid FROM farmer ORDER BY fid";  
                   $query_run = mysqli_query($con, $query);
                   $row = mysqli_num_rows($query_run);
                   echo '<h4> '.$row.'</h4>';
                ?>

              
              </div>
              <span class="count_bottom"><i class="green">4% </i> From last Week</span>
            </div>
            <div class="col-md-3 tile_stats_count">
              <span class="count_top"><i class="fa fa-paw"></i> Total Cow</span>
              <div class="count green">
                 <?php 
                   $query = "SELECT cid FROM cow ORDER BY cid";  
                   $query_run = mysqli_query($con, $query);
                   $row = mysqli_num_rows($query_run);
                   echo '<h4> '.$row.'</h4>';
                ?>
              </div>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>34% </i> From last Week</span>
            </div>
            <div class="col-md-3  tile_stats_count">
              <span class="count_top"><i class="fa fa-filter"></i> Total Collected Milk</span>
              <div class="count">
                <?php 
                   $query = "SELECT cid FROM cow ORDER BY cid";  
                   $query_run = mysqli_query($con, $query);
                   $row = mysqli_num_rows($query_run);
                   echo '<h4> '.$row.'</h4>';
                ?>                
              </div>
              <span class="count_bottom"><i class="red"><i class="fa fa-sort-desc"></i>12% </i> From last Week</span>
            </div>
            <div class="col-md-3  tile_stats_count">
              <span class="count_top"><i class="fa fa-filter"></i> Total Sold Milk</span>
              <div class="count">4,567</div>
              <span class="count_bottom"><i class="red"><i class="fa fa-sort-desc"></i>12% </i> From last Week</span>
            </div>
          </div>
        </div>
        <div class="row">
           <div id="chartContainer" style="height: 390px; width: 100%;"></div>
        </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Dairy Farm Management System - <a href="www.milco.lk"> Milco(PVT)LTD </a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>
<script src="jquery.min.js"></script>
        <script src="raphael-min.js"></script>
        <script src="canvasjs.min.js"></script>
    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="../vendors/Chart.js/dist/Chart.min.js"></script>
    <!-- jQuery Sparklines -->
    <script src="../vendors/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
    <!-- Flot -->
    <script src="../vendors/Flot/jquery.flot.js"></script>
    <script src="../vendors/Flot/jquery.flot.pie.js"></script>
    <script src="../vendors/Flot/jquery.flot.time.js"></script>
    <script src="../vendors/Flot/jquery.flot.stack.js"></script>
    <script src="../vendors/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="../vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="../vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="../vendors/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="../vendors/DateJS/build/date.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>