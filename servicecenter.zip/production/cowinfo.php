<?php
  session_start();
  include('../include/dbconn.php');
  include('../include/function.php');
  $user_data = checkLogin($con); 
  
?> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Dairy Farm Management System</title>

    <!-- Bootstrap -->
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link href="cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- Datatables -->
    
    <link href="../vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

    <!--Ajax Jquery com data load -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="dashboard.php" class="site_title"><i class="fa fa-paw"></i> <span>  Dairy Farm</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
              <?php include('../include/menu.php'); ?>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <?php include('../include/slider.php'); ?>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
          
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
         <?php include('../include/navigation.php'); ?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Cow Information </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <button class="btn btn-success btn-sm" data-toggle="modal" data-target=".add"> Add </button>
                      <div class="modal fade add" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-md">
                    <form class="form-label-left input_mask" method="POST" action="addCow.php">
                      <div class="modal-content">

                        <div class="modal-header">
                          <h4 class="modal-title" id="myModalLabel">Add Cow</h4>
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <div class="x_content">
                        <br />
                        <div class="col-md-6 col-sm-6  form-group has-feedback">
                          <input type="text" class="form-control has-feedback-right" id="inputSuccess2" placeholder="Supplier no:" name="spno">
                          <span class="fa fa-user form-control-feedback right" aria-hidden="true"></span>
                        </div> 
                      
                        <div class="col-md-6 col-sm-6  form-group has-feedback">
                          <input type="text" class="form-control" id="inputSuccess3" placeholder="Registor no:" name="cnum">
                          <span class="fa fa-user form-control-feedback right" aria-hidden="true"></span>
                        </div>

                        <div class="col-md-6 col-sm-6  form-group has-feedback">
                          <select class="form-control" name="gender">
                              <option value="">---Select Gender---</option>
                              <option value="male">Male</option>
                              <option value="female">Female</option>
                            </select>
                        </div>

                       <div class="col-md-6 col-sm-6  form-group has-feedback">
                          <?php 
                            $query = "SELECT * FROM Category";
                            $result = $con->query($query);

                          ?>
                            <select name="category" id="category" class="form-control" onchange="FetchDistric(this.value)"  required>
                                <option value="">Select Stage</option>
                                  <?php
                                    if ($result->num_rows > 0 ) {
                                       while ($row = $result->fetch_assoc()) {
                                        echo '<option value='.$row['ccid'].'>'.$row['category'].'</option>';
                                       }
                                    }
                                  ?> 
                           </select>
                       </div>
                       <div class="form-group has-feedback">
                        <p style="font-size: 14px; font-weight: bold; text-align:center; ">Date of Birth</p>
                        <input style="margin-top:-4%" type="date" class="form-control" id="inputSuccess4" placeholder="date of birth" name="dob" required>
                     </div>
                     <div class="custom-file mb-3">
                         <input type="file" class="custom-file-input" id="customFile" name="filename">
                         <label class="custom-file-label" for="customFile">Choose Profile Image</label>
                      </div>
                     </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" style="margin-right: 69%" data-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary" name="save_btn">Save </button>
                        </div>
                      </div>
                    </form>
                    </div>
                  </div>
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>

                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                   
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          
                          <th>SUP NO</th>
                          <th>SUPPLIER</th>
                          <th>COW NUMBER</th>
                          <th>GENDER</th> 
                          <th>DATE OF BIRTH</th>
                          <th>STAGE</th>
                          <th>STATUS</th>
                                                   
                          <th style="width: 10%"></th>
                        </tr>
                      </thead>
                      <tbody>

                          <?php
                           $sql = "SELECT fm.sno , fm.fullname , cw.gender ,cw.regno , cw.dob, cw.status , cat.category FROM farmer fm, cow cw ,category cat where cw.fid = fm.fid and cw.ccid = cat.ccid";
                           $query = $con->query($sql);
                            while($row = $query->fetch_assoc()){
                          ?>

                        <tr>
                          <td><?php echo $row['sno']; ?></td>
                          <td><?php echo $row['fullname']; ?> </td>
                          <td><?php echo $row['regno']; ?></td>
                          <td><?php echo $row['gender']; ?></td>
                          <td><?php echo $row['dob']; ?></td>                         
                          <td><?php echo $row['category']; ?></td>                         
                          <td><?php echo $row['status']; ?></td>                         
                          
                          
                          <td>
                            <button class="btn btn-info btn-sm editbtn" value="<?=$row['regno'];  ?>"><i class="fa fa-pencil"></i></button> 
                            <button class="btn btn-danger btn-sm deletecow" value="<?=$row['regno'];  ?>" ><i class="fa fa-trash"></i> </button>
                          </td>
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                    <!--edit model -->
                    <?php include("cow_model.php");?>
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>

              

              
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Dairy Farm Management System - Milco(PVT)LTD <a href="https://colorlib.com">Colorlib</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>
<script>
// Add the following code if you want the name of the file appear on select
$(".custom-file-input").on("change", function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});
</script>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="../vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="../vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="../vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="../vendors/jszip/dist/jszip.min.js"></script>
    <script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="../vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>

    <!--Combo Box Dataload-->
<script type="text/javascript">

  $(document).on('click', '.editbtn', function (e) {
                  e.preventDefault();
     var supid = $(this).val();
      
              $.ajax({
               
                type: "GET",
                url: "addCow.php?supid=" + supid,
                success: function (response) {
                    var res = jQuery.parseJSON(response);
                    if(res.status == 404) {
                        alert(res.message);
                    }else if(res.status == 200){ 

                      $('#usupno').val(res.data.sno);
                      $('#ufullname').val(res.data.fullname);
                      $('#ugender').val(res.data.gender).html(res.data.gender);
                      $('#umobilenum').val(res.data.regno);                     
                      $('#udate').val(res.data.dob);                     
                      $('#ustage').val(res.data.ccid).html(res.data.category);       
                      $('#ustatus').val(res.data.status).html(res.data.status);
                      $('#editmodel').modal('show');
                    }
               }
           });

        });


      $(document).on('click', '.deletefarmer', function (e) {
                  e.preventDefault();

                  if(confirm('Are you sure you want to delete this data?'))
                  {
                      //farmerid button value
                      var farmer_id = $(this).val();

                      $.ajax({
                          type: "POST",
                          url: "addFarmer.php",
                          data: {
                              'delete_farmer': true,
                              'farmer_id': farmer_id
                          },
                          success: function (response) {

                              var res = jQuery.parseJSON(response);
                              if(res.status == 500) {

                                  alert(res.message);
                              }else{
                                  $('#datatable').load(location.href + " #datatable");
                              }
                          }
                      });
                  }
              });

  $(document).on('click', '.deletecow', function (e) {
                  e.preventDefault();

                  if(confirm('Are you sure you want to delete this data?'))
                  {
                      //farmerid button value
                      var cow_id = $(this).val();

                      $.ajax({
                          type: "POST",
                          url: "addCow.php",
                          data: {
                              'delete_cow': true,
                              'cow_id': cow_id
                          },
                          success: function (response) {

                              var res = jQuery.parseJSON(response);
                              if(res.status == 500) {

                                  alert(res.message);
                              }else{
                                  $('#datatable').load(location.href + " #datatable");
                              }
                          }
                      });
                  }
              });
</script>

  </body>
</html>