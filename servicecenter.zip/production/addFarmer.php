<?php
	session_start();	
	include '../include/dbconn.php';
	include('../include/function.php');
	$user_data = checkLogin($con);

//farmer save
if(isset($_POST['save_btn']))
{	
	$province = mysqli_real_escape_string($con,$_POST['province']); 
	$distric = mysqli_real_escape_string($con,$_POST['distric']);
	$reg = mysqli_real_escape_string($con,$_POST['regional']);
	$mcc = mysqli_real_escape_string($con,$_POST['mcc']);
	$fms = mysqli_real_escape_string($con,$_POST['fms']);	
	$suptype = mysqli_real_escape_string($con,$_POST['suptype']);
	$spno = mysqli_real_escape_string($con,$_POST['spno']);
	$fname = mysqli_real_escape_string($con,$_POST['fname']);
	$gender =mysqli_real_escape_string($con,$_POST['gender']);
	$mnumber = mysqli_real_escape_string($con,$_POST['mnumber']);
	$address = mysqli_real_escape_string($con,$_POST['address']);
	$dob = mysqli_real_escape_string($con,$_POST['dob']);	
	$dor = mysqli_real_escape_string($con,$_POST['dor']);
	$numcow = mysqli_real_escape_string($con,$_POST['numcow']);		
	$aid = mysqli_real_escape_string($con,$_SESSION['aid']);



	
	$query ="insert into 
				farmer
					(sno,fullname,street,mobileNumber,statuse,numOfcow,dateofreg,gender,dob,pid,did,ftid,fmsid,regid,mccid,aid) 
				 values
				 	('$spno','$fname','$address','$mnumber','1','$numcow','$dor','$gender','$dob','$province','$distric','$suptype','$fms','$reg','$mcc','$aid')";
	
		mysqli_query($con,$query);
		echo $query;
		header('location: staffinfo.php');
		echo mysqli_error($con);
	
	
}
	
//click edit farmer
if(isset($_GET['supid']))
		{
			$supid = mysqli_real_escape_string($con,$_GET['supid']);
		   
		    $query = " SELECT * 
		    FROM farmer fm, province pr, distric dis, regional rg, mcc mc, fms fms, farmer_type fty  
		    WHERE fm.sno= '$supid' and fm.pid=pr.pid and dis.did = fm.did and rg.regid = fm.regid 
                          and mc.mccid= fm.mccid and fms.fmsid = fm.fmsid and fty.ftid= fm.ftid";
		    $query_run = mysqli_query($con, $query);

		    if(mysqli_num_rows($query_run) == 1)
		    {
		        $farmer = mysqli_fetch_array($query_run);

		        $res = [
		            'status' => 200,
		            'message' => 'Student Fetch Successfully by id',
		            'data' => $farmer
		        ];
		        echo json_encode($res);
		        return;
		    }
		    else
		    {
		        $res = [
		            'status' => 404,
		            'message' => 'Student Id Not Found'
		        ];
		        echo json_encode($res);
		        return;
		    }
		}

//update farmer

if(isset($_POST['update_farmer']))
{
	$province = mysqli_real_escape_string($con,$_POST['province']); 
	$distric = mysqli_real_escape_string($con,$_POST['distric']);
	$reg = mysqli_real_escape_string($con,$_POST['regional']);
	$mcc = mysqli_real_escape_string($con,$_POST['mcc']);
	$fms = mysqli_real_escape_string($con,$_POST['fms']);	
	$stype = mysqli_real_escape_string($con,$_POST['stype']);
	$spno = mysqli_real_escape_string($con,$_POST['spno']);
	$fname = mysqli_real_escape_string($con,$_POST['fname']);
	$gender =mysqli_real_escape_string($con,$_POST['gender']);
	$statuse =mysqli_real_escape_string($con,$_POST['statuse']);
	$mnumber = mysqli_real_escape_string($con,$_POST['mnumber']);
	$address = mysqli_real_escape_string($con,$_POST['address']);
	$dob = mysqli_real_escape_string($con,$_POST['dob']);	
	$dor = mysqli_real_escape_string($con,$_POST['dor']);
	$numcow = mysqli_real_escape_string($con,$_POST['numcow']);		
	$aid = mysqli_real_escape_string($con,$_SESSION['aid']);
	$rupdate=date('Y-m-d H:i:s');

    $query = "UPDATE farmer 
    		  SET fullname='$fname', street='$address', mobileNumber='$mnumber', statuse='$statuse' ,
    		  numOfcow='$numcow', dateofreg='$dor' ,gender='$gender' , dob='$dob',pid='$province',did='$distric' ,
    		  ftid='$stype' , fmsid='$fms' , regid='$reg' , mccid='$mcc', rupdate='$rupdate'
               WHERE sno='$spno'";
   
		mysqli_query($con,$query);
		echo $query;
		header('location: staffinfo.php');
	
}

//delete farmer
if(isset($_POST['delete_farmer']))
{
	$farmer_id = mysqli_real_escape_string($con,$_POST['farmer_id']);

	$query = "DELETE FROM farmer WHERE sno='$farmer_id'";	
	$query_run = mysqli_query($con,$query);
	if($query_run)
    {
        $res = [
            'status' => 200,
            'message' => 'Student Deleted Successfully'
        ];
        echo json_encode($res);
        return;
    }
    else
    {
        $res = [
            'status' => 500,
            'message' => 'Student Not Deleted'
        ];
        echo json_encode($res);
        return;
    }
}
