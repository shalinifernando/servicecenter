<?php
	session_start();	
	include '../include/dbconn.php';
	include('../include/function.php');
	$user_data = checkLogin($con);

	if(isset($_POST['save_btn'])){
		// $employee = $_POST['employee'];
		// $amount = $_POST['amount'];

	$spno = mysqli_real_escape_string($con,$_POST['spno']); 
	$cnum = mysqli_real_escape_string($con,$_POST['cnum']);
	$gender = mysqli_real_escape_string($con,$_POST['gender']);
	$category = mysqli_real_escape_string($con,$_POST['category']);
	$dob = mysqli_real_escape_string($con,$_POST['dob']);	
	$aid = mysqli_real_escape_string($con,$_SESSION['aid']);
		
		$sql = "SELECT * FROM farmer WHERE sno = '$spno'";
		$query = $con->query($sql);
		if($query->num_rows < 1){
			$_SESSION['msg'] = 'Famer not found';
		}
		else{		
			$row = $query->fetch_assoc();
			$farmerid= $row['fid'];
			$sql ="insert into 
					 cow
					 (fid,regno,gender,ccid,dob,aid,status) 
	 				 values
					 ('$farmerid','$cnum','$gender','$category','$dob','$aid','Available')";
			if($con->query($sql)){
				$_SESSION['msg'] = 'cow registration successfully';
				echo mysqli_error($con);
			}
			else{
				$_SESSION['msg'] = 'unscucessfully';
			}
		}
	}	
	else{
		$_SESSION['msg'] = 'Fill up add form first';
	}
	


//click edit cow
if(isset($_GET['supid']))
		{
			$supid = mysqli_real_escape_string($con,$_GET['supid']);
		   
		    $query = " SELECT fam.sno,fam.fullname,cat.category , cat.ccid , cw.status, cw.gender , cw.regno , cw.dob FROM cow cw ,farmer fam , category 			cat WHERE cw.regno = '$supid' and cw.fid=fam.fid and cw.ccid = cat.ccid";
		    $query_run = mysqli_query($con, $query);

		    if(mysqli_num_rows($query_run) == 1)
		    {
		        $farmer = mysqli_fetch_array($query_run);

		        $res = [
		            'status' => 200,
		            'message' => 'Cow Fetch Successfully by id',
		            'data' => $farmer
		        ];
		        echo json_encode($res);
		        return;
		    }
		    else
		    {
		        $res = [
		            'status' => 404,
		            'message' => 'Cow Id Not Found'
		        ];
		        echo json_encode($res);
		        return;
		    }
		}
//update farmer

if(isset($_POST['update_cow']))
{
	
	$spno = mysqli_real_escape_string($con,$_POST['spno']);
	$fname = mysqli_real_escape_string($con,$_POST['fname']);
	$gender =mysqli_real_escape_string($con,$_POST['gender']);
	$cownum = mysqli_real_escape_string($con,$_POST['mnumber']);
	$statuse =mysqli_real_escape_string($con,$_POST['statuse']);
	$stage =mysqli_real_escape_string($con,$_POST['stage']);
	$dob = mysqli_real_escape_string($con,$_POST['dob']);
		
	$rupdate=date('Y-m-d H:i:s');
	$aid = mysqli_real_escape_string($con,$_SESSION['aid']);

	
$sql = "SELECT * FROM farmer WHERE sno = '$spno'";
		$query = $con->query($sql);
		if($query->num_rows < 1){
			$_SESSION['msg'] = 'Famer not found';
		}
		else{		
			$row = $query->fetch_assoc();
			$farmerid= $row['fid'];
			$sql ="UPDATE cow
				  SET dob='$dob', regno='$cownum', ccid='$stage', status='$statuse',gender='$gender',fid='$farmerid',aid='$aid' WHERE regno='$cownum'";
			print_r($sql);
			echo $sql;
			if($con->query($sql)){
				$_SESSION['msg'] = 'cow update successfully';
				header('location: cowinfo.php');
				echo mysqli_error($con);
			}
			else{
				$_SESSION['msg'] = 'cannot update';
			}
		}
	}

//delete farmer
if(isset($_POST['delete_cow']))
{
	$cow_id = mysqli_real_escape_string($con,$_POST['cow_id']);

	$query = "DELETE FROM cow WHERE regno='$cow_id'";	
	$query_run = mysqli_query($con,$query);
	if($query_run)
    {
        $res = [
            'status' => 200,
            'message' => 'Student Deleted Successfully'
        ];
        echo json_encode($res);
        return;
    }
    else
    {
        $res = [
            'status' => 500,
            'message' => 'Student Not Deleted'
        ];
        echo json_encode($res);
        return;
    }
}