<?php 
include_once '../include/dbconn.php';

if (isset($_POST['province_id'])) {
	$query = "SELECT * FROM distric where pid=".$_POST['province_id'];
	$result = $con->query($query);
	if ($result->num_rows > 0 ) {
			echo '<option value="">Select Distric</option>';
		 while ($row = $result->fetch_assoc()) {
		 	echo '<option value='.$row['did'].'>'.$row['distric'].'</option>';
		 }
	}else{

		echo '<option>No State Found!</option>';
	}

}
elseif (isset($_POST['distric_id'])) {
	 

	$query = "SELECT * FROM Regional where did=".$_POST['distric_id'];
	$result = $con->query($query);
	if ($result->num_rows > 0 ) {
			echo '<option value="">Select Regional</option>';
		 while ($row = $result->fetch_assoc()) {
		 	echo '<option value='.$row['regid'].'>'.$row['regional'].'</option>';
		 }
	}else{

		echo '<option>No Regional Found!</option>';
	}

}
elseif (isset($_POST['regional_id'])) {
	 

	$query = "SELECT * FROM mcc where regid=".$_POST['regional_id'];
	$result = $con->query($query);
	if ($result->num_rows > 0 ) {
			echo '<option value="">Select MCC</option>';
		 while ($row = $result->fetch_assoc()) {
		 	echo '<option value='.$row['mccid'].'>'.$row['name'].'</option>';
		 }
	}else{

		echo '<option>No Regional Found!</option>';
	}

}
elseif (isset($_POST['mcc_id'])) {
	 

	$query = "SELECT * FROM fms where mccid=".$_POST['mcc_id'];
	$result = $con->query($query);
	if ($result->num_rows > 0 ) {
			echo '<option value="">Select FMS</option>';
		 while ($row = $result->fetch_assoc()) {
		 	echo '<option value='.$row['fmsid'].'>'.$row['fmsname'].'</option>';
		 }
	}else{

		echo '<option>No Regional Found!</option>';
	}

}


?>