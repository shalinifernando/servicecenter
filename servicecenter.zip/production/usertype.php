
  <?php include('include/link.php'); ?>


            <!-- menu profile quick info -->
            <?php include('include/menu.php'); ?>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <?php include('include/slidemenu.php'); ?>  
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
          
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <?php include('include/navigation.php'); ?> 
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>User Type Information<small>Table &nbsp; &nbsp;</small></h2>
                    <a href="useraccount.php"> <button class="fa fa-hand-o-left btn btn-success btn-sm" data-toggle="modal" data-target=".add"> User Account</button></a>
                    <ul class="nav navbar-right panel_toolbox">
                      <button class="btn btn-success btn-sm" data-toggle="modal" data-target=".add"> Add </button>
                      <div class="modal fade add" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-sm">
                    <form class="form-label-left input_mask" action="addUserType.php" method="POST">
                      <div class="modal-content">

                        <div class="modal-header">
                          <h4 class="modal-title" id="myModalLabel">Add User Type</h4>
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <div class="x_content">
                    <br />
                     
                                           
                      <div class="col-md-12 col-sm-12 form-group has-feedback">
                        <input type="text" class="form-control has-feedback-left" id="inputSuccess2" placeholder="User Type" name="txt_usertype">
                        <span class="fa fa-user-secret form-control-feedback left" aria-hidden="true" ></span>
                      </div>
                      
                     
                      
                  </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" style="margin-right: 46%" data-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary" name="utsave">Save </button>
                        </div>
                      </div>
                    </form>
                    </div>
                  </div>
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>

                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                   
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                         <tr>
                          <th>ID</th>
                          <th>User Type</th>                   
                          <th style="width: 10%"></th>
                         </tr>
                      </thead>


                      <tbody>
                          <?php
                           $sql = 
                           "SELECT * FROM usertype";
                           $query = $con->query($sql);
                            while($row = $query->fetch_assoc()){
                          ?>
                        <tr>
                          <td><?php echo $row['utid']; ?></td>
                          <td><?php echo $row['user_type']; ?></td>                        
                          <td>
                            <button class="btn btn-info btn-sm editbtn"  data-toggle="modal" data-target=".edit" value="<?=$row['utid'];  ?>"><i class="fa fa-pencil"></i></button>
                          </td>
                        </tr>
                        <?php } ?>
                        
                      </tbody>
                    </table>
                    <div class="modal fade edit" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog ">
                    <form class="form-label-left input_mask" action="addUserType.php" method="POST">
                      <div class="modal-content">

                        <div class="modal-header">
                          <h4 class="modal-title" id="myModalLabel">Update User Type</h4>
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <div class="x_content">
                    <br />
                     
                      
                        <div class="form-group">
                         <label for="edit_firstname" class="col-sm-3 control-label">User Type</label>
                            <div class="col-sm-9">
                            <input type="text" class="form-control" id="utype" placeholder="User Type" name="txt_usertype">
                            <input type="text" hidden class="form-control" id="utypeid" placeholder="usertype" name="txt_usertypeid">
                            </div>
                        </div> 
                        
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary"  data-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary" name="ustype">Update </button>
                        </div>
                      </div>
                    </form>
                    </div>
                  </div>
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>    
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
         <?php include('include/footer.php'); ?> 
        <!-- /footer content -->
      </div>
    </div>
     <!-- link script -->
     <?php include('include/script.php'); ?>

     <script type="text/javascript">

        $(document).on('click', '.editbtn', function (e) {
        e.preventDefault();
        var utid = $(this).val();
       
              $.ajax({
               
                type: "GET",
                url: "addUserType.php?utid=" + utid,
                success: function (response) {
                    var res = jQuery.parseJSON(response);
                    if(res.status == 404) {
                        alert(res.message);
                    }else if(res.status == 200){ 
                    
                      $('#utypeid').val(res.data.utid);                     
                      $('#utype').val(res.data.user_type);                     
                                       
                     
                    }
               }
           });

        });

     </script>
  </body>

</html>