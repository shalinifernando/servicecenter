<?php 
include '../include/dbconn.php';

$roffice = $_POST['roffice'];
$mcccode = $_POST['mcccode'];
$mccname = $_POST['mccname'];
$scode = $_POST['scode'];				

$query = "insert into mcc(name,shortcode,mcccode,regional_regid) values('$mccname','$scode','$mcccode','$roffice')";
mysqli_query($con,$query);
echo mysqli_error($con);
header('location: mcc.php');