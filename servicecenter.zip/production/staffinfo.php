<?php
  session_start();
  include('../include/dbconn.php');
  include('../include/function.php');
  $user_data = checkLogin($con); 
  
?> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Dairy Farm Management System</title>

    <!-- Bootstrap -->
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link href="cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- Datatables -->
    
    <link href="../vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

    <!--Ajax Jquery com data load -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="dashboard.php" class="site_title"><i class="fa fa-paw"></i> <span>  Dairy Farm</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
              <?php include('../include/menu.php'); ?>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <?php include('../include/slider.php'); ?>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
          
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
         <?php include('../include/navigation.php'); ?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Farmer Information </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <button class="btn btn-success btn-sm" data-toggle="modal" data-target=".add"> Add </button>
                      <div class="modal fade add" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-md">
                    <form class="form-label-left input_mask" method="POST" action="addFarmer.php">
                      <div class="modal-content">

                        <div class="modal-header">
                          <h4 class="modal-title" id="myModalLabel">Add Farmer</h4>
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <div class="x_content">
                    <br />

                      <div class="col-md-6 col-sm-6  form-group has-feedback">

                        <?php 
                          $query = "SELECT * FROM province Order by province";
                          $result = $con->query($query);

                        ?>
                        <select name="province" id="province" class="form-control" onchange="FetchDistric(this.value)"  required>
                            <option value="">Select Province</option>
                              <?php
                                if ($result->num_rows > 0 ) {
                                   while ($row = $result->fetch_assoc()) {
                                    echo '<option value='.$row['pid'].'>'.$row['province'].'</option>';
                                   }
                                }
                              ?> 
                      </select>
                     </div>

                      <div class="col-md-6 col-sm-6  form-group has-feedback">
                        <select name="distric" id="distric" class="form-control" onchange="FetcRegional(this.value)"  required>
                          <option>Select Distric</option>
                        </select>
                      </div>


                      <div class="col-md-6 col-sm-6  form-group has-feedback">
                        <select name="regional" id="regional" class="form-control" onchange="FetchMcc(this.value)"  required>
                          <option>Select Regional</option>
                        </select>
                      </div>

                      <div class="col-md-6 col-sm-6  form-group has-feedback">
                        <select name="mcc" id="mcc" class="form-control"  onchange="FetchFms(this.value)" required>
                          <option>Select MCC</option>
                        </select>
                      </div>

                      <div class="col-md-6 col-sm-6  form-group has-feedback">
                           <select name="fms" id="fms" class="form-control">
                              <option>Select FMS</option>
                            </select>
                          
                      </div>
                      <div class="col-md-6 col-sm-6  form-group has-feedback">
                          <select class="form-control" name="suptype" id="inputSuccess6" required>
                       
                           <option>--SUPPLIER TYPE--</option>
    
                            <?php
                              $sql = "SELECT * FROM farmer_type";
                              $query = $con->query($sql);
                              while($prow = $query->fetch_assoc()){
                                echo "
                                  <option value='".$prow['ftid']."'>".$prow['farmerType']."</option>
                                ";
                              }
                            ?>             
                         
                      </select>
                      </div>


                      <div class="col-md-6 col-sm-6  form-group has-feedback">
                        <input type="text" class="form-control has-feedback-right" id="inputSuccess2" placeholder="Supplier no" name="spno">
                        <span class="fa fa-user form-control-feedback right" aria-hidden="true"></span>
                      </div> 
                      
                      <div class="col-md-6 col-sm-6  form-group has-feedback">
                        <input type="text" class="form-control" id="inputSuccess3" placeholder="Farmer name" name="fname">
                        <span class="fa fa-user form-control-feedback right" aria-hidden="true"></span>
                      </div>

                      <div class="col-md-6 col-sm-6  form-group has-feedback">
                        <select class="form-control" name="gender">
                            <option>---Select Gender---</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                          </select>
                      </div>

                       <div class="col-md-6 col-sm-6  form-group has-feedback">
                        <input type="text" class="form-control has-feedback-right" id="inputSuccess10" placeholder="MOBILE NUMBER" name="mnumber">
                        <span class="fa fa-phone form-control-feedback right" aria-hidden="true"></span>
                      </div>

                      <div class="col-md-12 col-sm-12  form-group has-feedback">
                        <textarea class="col-md-12 col-sm-12  form-control" name="address" placeholder="Address"></textarea>
                        <span class="fa fa-envelope form-control-feedback right" aria-hidden="true"></span>
                      </div>
                       <div class="col-md-6 col-sm-6  form-group has-feedback">
                        <p style="font-size: 14px; font-weight: bold; text-align:center; ">Date of Birth</p>
                        <input style="margin-top:-4%" type="date" class="form-control" id="inputSuccess4" placeholder="date of birth" name="dob" required>
                       
                    </div>

                    <div class="col-md-6 col-sm-6  form-group has-feedback">
                        <p style="font-size: 14px; font-weight: bold; text-align: center;">Date of Register</p>
                        <input style="margin-top:-4%" type="date" class="form-control" id="inputSuccess9" placeholder="DATE OF REGISTER" name="dor">
                       
                    </div>
                      
                     

                      <div class="col-md-6 col-sm-6  form-group has-feedback">
                        <input type="text" class="form-control has-feedback-right" id="inputSuccess11" placeholder="NUMBER OF ANIMAL" name="numcow">
                        <span class="fa fa-paw form-control-feedback right" aria-hidden="true"></span>
                      </div>

                     <div class="custom-file mb-3">
                         <input type="file" class="custom-file-input" id="customFile" name="filename">
                         <label class="custom-file-label" for="customFile">Choose Profile Image</label>
                      </div>
                  </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" style="margin-right: 69%" data-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary" name="save_btn">Save </button>
                        </div>
                      </div>
                    </form>
                    </div>
                  </div>
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>

                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                   
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          
                        <th scope="col">Full Name</th>
                                <th scope="col">Birthday</th>
                                <th scope="col">address number</th>
                                <th scope="col">address street</th>
                                <th scope="col">address city </th>
                                <th scope="col">address district</th>
                                <th scope="col">Mobile number</th>
                                <th scope="col"> Action </th>                         
                          <th style="width: 10%"></th>
                        </tr>
                      </thead>
                      <tbody>

                          <?php
                           $sql = "SELECT * FROM farmer fm, province pr ,distric di,regional rg , mcc mc , fms fms where fm.pid = pr.pid and fm.did = di.did and fm.mccid = mc.mccid  and fm.fmsid = fms.fmsid and fm.regid= rg.regid ";
                           $query = $con->query($sql);
                            while($row = $query->fetch_assoc()){
                          ?>

                        <tr>
                          <td><?php echo $row['province']; ?></td>
                          <td><?php echo $row['distric']; ?> </td>
                          <td><?php echo $row['regional']; ?></td>
                          <td><?php echo $row['name']; ?></td>
                          <td><?php echo $row['fmsname']; ?></td>
                          <td><?php echo $row['sno']; ?></td>
                          <td><?php echo $row['fullname']; ?></td>
                          <td><?php echo $row['dob']; ?></td>
                          <td><?php echo $row['mobileNumber']; ?></td>
                          <td><?php echo $row['numOfcow']; ?></td>
                          <td><?php echo $row['dateofreg']; ?></td>
                          <td><?php echo $row['statuse']; ?></td>
                          
                          
                          <td>
                            <button class="btn btn-info btn-sm editbtn" value="<?=$row['sno'];  ?>"><i class="fa fa-pencil"></i></button> 
                            <button class="btn btn-danger btn-sm deletefarmer" value="<?=$row['sno'];  ?>" ><i class="fa fa-trash"></i> </button></td>
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                    <!--edit model -->
                    <?php include("farmer_model.php");?>
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>

              

              
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Dairy Farm Management System - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>
<script>
// Add the following code if you want the name of the file appear on select
$(".custom-file-input").on("change", function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});
</script>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="../vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="../vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="../vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="../vendors/jszip/dist/jszip.min.js"></script>
    <script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="../vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>

    <!--Combo Box Dataload-->
<script type="text/javascript">
function FetchDistric(id){
    $('#distric').html('');
    $('#regional').html('<option>Select Regional</option>');
    $.ajax({
      type:'post',
      url: 'ajaxdata.php',
      data : { province_id : id},
      success : function(data){
         $('#distric').html(data);
      }

    })
  }

  function FetcRegional(id){ 
    $('#regional').html('');
    $('#mcc').html('<option>Select MCC</option>');
    $.ajax({
      type:'post',
      url: 'ajaxdata.php',
      data : { distric_id : id},
      success : function(data){
         $('#regional').html(data);
      }

    })
  }
 function FetchMcc(id){ 
    $('#mcc').html('');
     $('#mcc').html('<option>Select FMS</option>');
    $.ajax({
      type:'post',
      url: 'ajaxdata.php',
      data : { regional_id : id},
      success : function(data){
         $('#mcc').html(data);
      }

    })
  }
  function FetchFms(id){ 
    $('#fms').html('');
    $.ajax({
      type:'post',
      url: 'ajaxdata.php',
      data : { mcc_id : id},
      success : function(data){
         $('#fms').html(data);
      }

    })
  }

  $(document).on('click', '.editbtn', function (e) {
                  e.preventDefault();
     var supid = $(this).val();
      
              $.ajax({
               
                type: "GET",
                url: "addFarmer.php?supid=" + supid,
                success: function (response) {
                    var res = jQuery.parseJSON(response);
                    if(res.status == 404) {
                        alert(res.message);
                    }else if(res.status == 200){ 

                      $('#usupno').val(res.data.sno);
                      $('#ufullname').val(res.data.fullname);
                      $('#ugender').val(res.data.gender).html(res.data.gender);
                      $('#umobilenum').val(res.data.mobileNumber);
                      $('#uaddress').val(res.data.street);
                      $('#udate').val(res.data.dob);
                      $('#urdate').val(res.data.dateofreg);
                      $('#unumcow').val(res.data.numOfcow);
                      $('#ustype').val(res.data.ftid).html(res.data.farmerType);
                      $('#uprovince').val(res.data.pid).html(res.data.province);
                      $('#udistric').val(res.data.did).html(res.data.distric);
                      $('#uregional').val(res.data.regid).html(res.data.regional);
                      $('#umcc').val(res.data.mccid).html(res.data.name);
                      $('#ufms').val(res.data.fmsid).html(res.data.fmsname);
                      $('#ustatus').val(res.data.statuse).html(res.data.statuse);
                      $('#editmodel').modal('show');
                    }
               }
           });

        });


  //  });


$(document).on('submit', '#updateStudent', function (e) {
            e.preventDefault();

            var formData = new FormData(this);
            formData.append("update_student", true);

            $.ajax({
                type: "POST",
                url: "code.php",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    
                    var res = jQuery.parseJSON(response);
                    if(res.status == 422) {
                        $('#errorMessageUpdate').removeClass('d-none');
                        $('#errorMessageUpdate').text(res.message);

                    }else if(res.status == 200){

                        $('#errorMessageUpdate').addClass('d-none');

                        alertify.set('notifier','position', 'top-right');
                        alertify.success(res.message);
                        
                        $('#studentEditModal').modal('hide');
                        $('#updateStudent')[0].reset();

                        $('#myTable').load(location.href + " #myTable");

                    }else if(res.status == 500) {
                        alert(res.message);
                    }
                }
            });

        });
      $(document).on('click', '.deletefarmer', function (e) {
                  e.preventDefault();

                  if(confirm('Are you sure you want to delete this data?'))
                  {
                      //farmerid button value
                      var farmer_id = $(this).val();

                      $.ajax({
                          type: "POST",
                          url: "addFarmer.php",
                          data: {
                              'delete_farmer': true,
                              'farmer_id': farmer_id
                          },
                          success: function (response) {

                              var res = jQuery.parseJSON(response);
                              if(res.status == 500) {

                                  alert(res.message);
                              }else{
                                  $('#datatable').load(location.href + " #datatable");
                              }
                          }
                      });
                  }
              });
</script>

  </body>
</html>