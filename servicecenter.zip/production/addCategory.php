<?php 
include '../include/dbconn.php';

$category = $_POST['category'];
$query = "insert into category(category) values('$category')";
mysqli_query($con,$query);
echo mysqli_error($con);
header('location: category.php');