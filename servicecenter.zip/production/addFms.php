<?php 
include '../include/dbconn.php';


$fmsname = $_POST['fmsname'];
$fmsnum = $_POST['fmsnum'];
$shortcode = $_POST['shortcode'];
$mcc_id = $_POST['mcc_id'];


$query = "insert into fms(fmsname,fmsnum,shortcode,mccid) values('$fmsname','$fmsnum','$shortcode','$mcc_id')";
mysqli_query($con,$query);
echo mysqli_error($con);
header('location: fms.php');
