
<!--edit farmer -->

<div class="modal fade" id="editmodel" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Edit Milk Collection Details</h4>
                   <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">×</span>
                    </button>
          </div>
              <div class="modal-body">
                <form class="form-horizontal" method="POST" action="addMilck.php">
                  <input type="hidden" class="empid" name="id">
                    <div class="form-group">
                     <label for="edit_firstname" class="col-sm-3 control-label">Supplier NO :</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" id="usupno" name="spno">
                          <input type="hidden" class="form-control" id="umid" name="mid">
                        </div>
                    </div>
                     <div class="form-group">
                      <label for="datepicker_edit" class="col-sm-3 control-label">Date</label>

                      <div class="col-sm-9"> 
                        <div class="date">
                          <input type="date" class="form-control" id="udate" name="dob">
                        </div>
                      </div>
                  </div>
                   
                  <div class="form-group">
                      <label for="edit_contact" class="col-sm-3 control-label">FAT</label>

                      <div class="col-sm-9">
                        <input type="text" class="form-control" id="ufat" name="fat">
                      </div>
                  </div>
                  <div class="form-group">
                      <label for="edit_contact" class="col-sm-3 control-label">SNF</label>

                      <div class="col-sm-9">
                        <input type="text" class="form-control" id="usnf" name="snf">
                      </div>
                  </div>
                 
                  <div class="form-group">
                      <label for="edit_position" class="col-sm-3 control-label">Unit</label>

                      <div class="col-sm-9">
                        <select class="form-control" name="unit"  required>
                          <option selected id="uunit"></option>
                          <option value="LTRs">LTRs</option>
                          <option value="KGs">KGs</option>
                        </select>
                      </div>
                  </div>

                  <div class="form-group">
                      <label for="edit_contact" class="col-sm-3 control-label">QTY</label>

                      <div class="col-sm-9">
                        <input type="text" class="form-control" id="uqty" name="qty">
                      </div>
                  </div>
                  
                  
            </div>
                        <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary" name="update_milk">Update </button>
                        </div>
        </div>
      </form>
</div>
</div>
</div>


