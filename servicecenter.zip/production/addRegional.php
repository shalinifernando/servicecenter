<?php 
include '../include/dbconn.php';

$roffice = $_POST['roffice'];
$scode = $_POST['scode'];
$distric = $_POST['distric'];

		
			
$query = "insert into regional(regional,shortcode,did) values('$roffice','$scode','$distric')";
mysqli_query($con,$query);
echo mysqli_error($con);
header('location: regional.php');