<?php
	session_start();	
	include '../include/dbconn.php';
	include('../include/function.php');
	$user_data = checkLogin($con);

	if(isset($_POST['save_btn'])){
	
	$cnumber = mysqli_real_escape_string($con,$_POST['cnumber']); 	
	$dob = mysqli_real_escape_string($con,$_POST['dob']);	
	$remark = mysqli_real_escape_string($con,$_POST['remark']);		
	$aid = mysqli_real_escape_string($con,$_SESSION['aid']);
		
		$sql = "SELECT regno FROM cow WHERE regno = '$cnumber'";
		$query = $con->query($sql);
		if($query->num_rows < 1){
			$_SESSION['msg'] = 'Cow not found';
		}

		else{		
			$row = $query->fetch_assoc();
			$cownum= $row['regno'];
			$sql ="insert into 
					 vaccine
					 (regno,date,remark,aid) 
	 				 values
					 ('$cownum','$dob','$remark','$aid')";
			if($con->query($sql)){
				$_SESSION['msg'] = 'vaccince registration successfully';
				header('location: vaccine.php');
				echo mysqli_error($con);
			}
			else{
				$_SESSION['msg'] = 'unscucessfully';
			}
		}
	}	
	else{
		$_SESSION['msg'] = 'Fill up add form first';
	}
	
//click edit vaccine
if(isset($_GET['regno']))
		{
			$regno = mysqli_real_escape_string($con,$_GET['regno']);
		   
		    $query = " SELECT * FROM vaccine WHERE vid = '$regno'";
		    $query_run = mysqli_query($con, $query);

		    if(mysqli_num_rows($query_run) == 1)
		    {
		        $farmer = mysqli_fetch_array($query_run);

		        $res = [
		            'status' => 200,
		            'message' => 'Cow Fetch Successfully by id',
		            'data' => $farmer
		        ];
		        echo json_encode($res);
		        return;
		    }
		    else
		    {
		        $res = [
		            'status' => 404,
		            'message' => 'Cow Id Not Found'
		        ];
		        echo json_encode($res);
		        return;
		    }
		}
//update vaccine

if(isset($_POST['update_cow']))
{
	$vid = mysqli_real_escape_string($con,$_POST['vid']);
	$cnumber = mysqli_real_escape_string($con,$_POST['cnum']); 	
	$dob = mysqli_real_escape_string($con,$_POST['dob']);	
	$remark = mysqli_real_escape_string($con,$_POST['remark']);		
	$rupdate=date('Y-m-d H:i:s');
	$aid = mysqli_real_escape_string($con,$_SESSION['aid']);


$sql = "SELECT * FROM vaccine WHERE regno = '$cnumber'";
		$query = $con->query($sql);
		if($query->num_rows < 1){
			$_SESSION['msg'] = 'Cow not found';
		}
		else{		
			$row = $query->fetch_assoc();
			$farmerid= $row['fid'];
			$sql ="UPDATE vaccine
				  SET regno='$cnumber',date='$dob',remark='$remark',aid='$aid' WHERE vid='$vid'";
			
			if($con->query($sql)){
				$_SESSION['msg'] = 'cow update successfully';
				header('location: vaccine.php');
				echo mysqli_error($con);
			}
			else{
				$_SESSION['msg'] = 'cannot update';
			}
		}
	}

//delete vacacine
if(isset($_POST['delete_cow']))
{
	$cow_id = mysqli_real_escape_string($con,$_POST['cow_id']);

	$query = "DELETE FROM vaccine WHERE vid='$cow_id'";	
	$query_run = mysqli_query($con,$query);
	if($query_run)
    {
        $res = [
            'status' => 200,
            'message' => 'Student Deleted Successfully'
        ];
        echo json_encode($res);
        return;
    }
    else
    {
        $res = [
            'status' => 500,
            'message' => 'Student Not Deleted'
        ];
        echo json_encode($res);
        return;
    }
}