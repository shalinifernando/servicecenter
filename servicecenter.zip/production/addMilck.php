<?php
	session_start();	
	include '../include/dbconn.php';
	include('../include/function.php');
	$user_data = checkLogin($con);

	if(isset($_POST['save_btn'])){
	
	$snumber = mysqli_real_escape_string($con,$_POST['snumber']); 	
	$unit = mysqli_real_escape_string($con,$_POST['unit']);
	$dob = mysqli_real_escape_string($con,$_POST['dob']);	
	$qty = mysqli_real_escape_string($con,$_POST['qty']);	
	$fat = mysqli_real_escape_string($con,$_POST['fat']);	
	$snf = mysqli_real_escape_string($con,$_POST['snf']);	
	$aid = mysqli_real_escape_string($con,$_SESSION['aid']);
		
		$sql = "SELECT * FROM farmer WHERE sno = '$snumber'";
		$query = $con->query($sql);

		if($query->num_rows < 1){
			$_SESSION['msg'] = 'Famer not found';
		}
		else{
			$row = $query->fetch_assoc();
			$farmerid= $row['fid'];
			$sql ="insert into 
					 milk
					 (fat,snf,unit,date,fid,qty,aid,cid) 
	 				 values
					 ('$fat','$snf','$unit','$dob','$farmerid','$qty','$aid','1')";

			if($con->query($sql)){
				$_SESSION['msg'] = 'milk registration successfully';
				header('location: milkcollection.php');
				echo mysqli_error($con);
			}
			else{
				$_SESSION['msg'] = 'unscucessfully';
			}
		}
	}	
	else{
		$_SESSION['msg'] = 'Fill up add form first';
	}
	
//click edit milk
if(isset($_GET['regno']))
		{
			$regno = mysqli_real_escape_string($con,$_GET['regno']);
		   
		  $query = " SELECT fm.sno , mi.fat , mi.snf , mi.unit ,mi.date,mi.qty ,mi.fid ,mi.mid FROM milk mi , farmer fm WHERE mi.mid = '$regno' and mi.fid = fm.fid";
		    $query_run = mysqli_query($con, $query);

		    if(mysqli_num_rows($query_run) == 1)
		    {
		        $farmer = mysqli_fetch_array($query_run);

		        $res = [
		            'status' => 200,
		            'message' => 'Cow Fetch Successfully by id',
		            'data' => $farmer
		        ];
		        echo json_encode($res);
		        return;
		    }
		    else
		    {
		        $res = [
		            'status' => 404,
		            'message' => 'Cow Id Not Found'
		        ];
		        echo json_encode($res);
		        return;
		    }
		}
//update vaccine

if(isset($_POST['update_milk']))
{
	$spno = mysqli_real_escape_string($con,$_POST['spno']);
	$mid = mysqli_real_escape_string($con,$_POST['mid']);
	$dob = mysqli_real_escape_string($con,$_POST['dob']); 	
	$fat = mysqli_real_escape_string($con,$_POST['fat']);	
	$snf = mysqli_real_escape_string($con,$_POST['snf']);		
	$unit = mysqli_real_escape_string($con,$_POST['unit']);		
	$qty = mysqli_real_escape_string($con,$_POST['qty']);

echo $mid;

$sql = "SELECT fid,sno FROM farmer WHERE sno = '$spno'";
		$query = $con->query($sql);
		if($query->num_rows < 1){
			$_SESSION['msg'] = 'Farmer not found';
		}
		else{		
			$row = $query->fetch_assoc();
			$sql ="UPDATE milk
				  SET fat='$fat',snf='$snf' , unit='$unit' , qty='$qty' where mid = '$mid'";
				  
			
			if($con->query($sql)){
				$_SESSION['msg'] = 'Farmer update successfully';
				echo $sql;
				header('location: milkcollection.php');

				echo mysqli_error($con);
			}
			else{
				$_SESSION['msg'] = 'cannot update';
			}
		}
	}

//delete farmer
if(isset($_POST['delete_milk']))
{
	$milkid = mysqli_real_escape_string($con,$_POST['milkid']);

	$query = "DELETE FROM milk WHERE mid='$milkid'";	
	$query_run = mysqli_query($con,$query);
	if($query_run)
    {
        $res = [
            'status' => 200,
            'message' => 'Student Deleted Successfully'
        ];
        echo json_encode($res);
        return;
    }
    else
    {
        $res = [
            'status' => 500,
            'message' => 'Student Not Deleted'
        ];
        echo json_encode($res);
        return;
    }
}