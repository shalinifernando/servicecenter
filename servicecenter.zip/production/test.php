<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>
<body>
<form class="insert-form" id="insert-form" method="post" action="" >
<table>
  <tr>
    <thead>
      <th>Farmer ID</th>
      <th>Cow Number</th>
      <th>Gender</th>
      <th>Stage</th>
      <th>Insuired</th>
      <th>Add or Remove</th>
    </thead>
  </tr>
<tr>
  <tr>
  <tbody>
    <td><input type="textbox" name="snom" id="snom" placeholder="supplier number"></td>
    <td><input type="textbox" name="cnum" id="cnum" placeholder="Cow Number"></td>
    <td><input type="textbox" name="gender" id="gender" placeholder="Gender"></td>
    <td><input type="textbox" name="stage" id="stage" placeholder="stage"></td>
    <td><input type="textbox" name="stage" id="stage" placeholder="insuired"></td>
    <td><input type="button" name="add" id="add" value="ADD"></td>
  </tbody>
</tr>
</table>
</form>
<script type="text/javascript">
  $(document).ready(function()){
     alert('hello');
var html= '<tr><tbody><td><input type="textbox" name="snom" id="snom" placeholder="supplier number"></td><td><input type="textbox" name="cnum" id="cnum" placeholder="Cow Number"></td><td><input type="textbox" name="gender" id="gender" placeholder="Gender"></td><td><input type="textbox" name="stage" id="stage" placeholder="stage"></td><td><input type="textbox" name="stage" id="stage" placeholder="insuired"></td><td><input type="button" name="add" id="add" value="ADD"></td></tbody></tr>';
var x=1;
$("#ADD").click(function(){
 
});
  }
</script>

</body>
</html>