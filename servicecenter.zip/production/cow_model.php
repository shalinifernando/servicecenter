
<!--edit farmer -->

<div class="modal fade" id="editmodel" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Edit Cow Details</h4>
                   <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">×</span>
                    </button>
          </div>
              <div class="modal-body">
                <form class="form-horizontal" method="POST" action="addCow.php">
                  <input type="hidden" class="empid" name="id">
                    <div class="form-group">
                     <label for="edit_firstname" class="col-sm-3 control-label">SP Number</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" id="usupno" name="spno">
                        </div>
                    </div>
                    <div class="form-group">
                      <label for="edit_lastname" class="col-sm-3 control-label">Supplier Name</label>
                      <div class="col-sm-9">
                        <input type="text" class="form-control" id="ufullname" name="fname">
                     </div>
                  </div>
                  <div class="form-group">
                      <label for="edit_contact" class="col-sm-3 control-label">Cow Number</label>
                      <div class="col-sm-9">
                        <input type="text" class="form-control" id="umobilenum" name="mnumber">
                      </div>
                  </div>
                  <div class="form-group">
                      <label for="edit_gender" class="col-sm-3 control-label">Gender</label>
                      <div class="col-sm-9"> 
                          <select class="form-control" name="gender" id="edit_gender">
                            <option selected id="ugender"></option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                          </select>
                      </div>
                  </div>                  
        
                  <div class="form-group">
                      <label for="datepicker_edit" class="col-sm-3 control-label">Birthdate</label>

                      <div class="col-sm-9"> 
                        <div class="date">
                          <input type="date" class="form-control" id="udate" name="dob">
                        </div>
                      </div>
                  </div>
                  

                  <div class="form-group">
                      <label for="edit_stage" class="col-sm-3 control-label">Stage</label>
                      <div class="col-sm-9"> 
                          <select class="form-control" name="stage" id="edit_stage">
                            <option selected id="ustage"></option>
                               <?php
                                $sql = "SELECT * FROM category";
                                $query = $con->query($sql);
                                while($prow = $query->fetch_assoc()){
                                  echo "
                                    <option value='".$prow['ccid']."'>".$prow['category']."</option>
                                  ";
                                 }
                                ?>
                          </select>
                      </div>
                  </div>    

                 




                   <div class="form-group">
                      <label for="edit_position" class="col-sm-3 control-label">Status</label>

                      <div class="col-sm-9">
                        <select class="form-control" name="statuse" id="status">
                          <option selected id="ustatus"></option>
                          <option value="Available">Available</option>
                          <option value="Sold">Sold</option>
                          <option value="Death">Death</option>
                          
                        </select>
                      </div>
                  </div>
            </div>
                        <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary " name="update_cow">Update </button>
                        </div>
        </div>
      </form>
</div>
</div>
</div>


