
<!--edit vaccine -->

<div class="modal fade" id="editmodel" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Edit vaccine Details</h4>
                   <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">×</span>
                    </button>
          </div>
              <div class="modal-body">
                <form class="form-horizontal" method="POST" action="addVaccine.php">
                  <input type="hidden" class="empid" name="id">
                    <div class="form-group">
                     <label for="edit_firstname" class="col-sm-3 control-label">COW NUMBER</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" id="ucownum" name="cnum">
                          <input type="hidden" class="form-control" id="uvid" name="vid">
                        </div>
                    </div>
                    <div class="form-group">
                      <label for="edit_lastname" class="col-sm-3 control-label">Date of birth</label>
                      <div class="col-sm-9">
                        <input type="date" class="form-control" id="udob" name="dob">
                     </div>
                  </div>
                  <div class="form-group">
                      <label for="edit_contact" class="col-sm-3 control-label">Remark</label>
                      <div class="col-sm-9">
                        <input type="text" class="form-control" id="ureamrk" name="remark">
                      </div>
                  </div>
                  
                   
            </div>
                        <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary " name="update_cow">Update </button>
                        </div>
        </div>
      </form>
</div>
</div>
</div>


