-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 09, 2022 at 05:24 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dairyf`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(11) NOT NULL,
  `username` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `fname` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `lastname` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `utid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `username`, `password`, `fname`, `lastname`, `utid`) VALUES
(1, 'admin', '123', 'admin', 'admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `ccid` int(11) NOT NULL,
  `category` varchar(45) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`ccid`, `category`) VALUES
(1, 'Hallikar'),
(2, 'Amritmahal');

-- --------------------------------------------------------

--
-- Table structure for table `cow`
--

CREATE TABLE `cow` (
  `cid` int(11) NOT NULL,
  `dob` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `regno` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `gender` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `ccid` int(11) NOT NULL,
  `status` varchar(25) COLLATE utf8_bin NOT NULL,
  `fid` int(11) NOT NULL,
  `aid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `cow`
--

INSERT INTO `cow` (`cid`, `dob`, `regno`, `gender`, `ccid`, `status`, `fid`, `aid`) VALUES
(5, '2022-10-01', 'cnoranukahtes123', 'female', 2, 'Sold', 4, 1),
(6, '2022-10-02', 'cnoranukahtes1234', 'female', 2, 'Available', 6, 1),
(8, '2022-10-01', 'cnoranukahtes1', 'female', 1, 'Death', 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `distric`
--

CREATE TABLE `distric` (
  `did` int(11) NOT NULL,
  `distric` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `pid` int(11) NOT NULL,
  `shortCode` varchar(45) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `distric`
--

INSERT INTO `distric` (`did`, `distric`, `pid`, `shortCode`) VALUES
(1, 'Ampara', 2, 'AM'),
(2, 'Anuradhapura', 3, 'AP'),
(3, 'Badulla', 7, 'BD'),
(4, 'Batticaloa', 2, 'BT'),
(5, 'Colombo', 8, 'CL'),
(6, 'Galle', 9, 'GL'),
(7, 'Gampaha', 8, 'GP'),
(8, 'Hambanthota', 9, 'HB'),
(9, 'Jaffna', 4, 'JF'),
(10, 'Kaluthara', 8, 'KL'),
(11, 'Kandy', 1, 'KY'),
(12, 'Kegalle', 6, 'KG'),
(13, 'Kilinochchi', 4, 'KL'),
(14, 'Kurunegala', 5, 'KN'),
(15, 'Mannar', 4, 'MN'),
(16, 'Matara', 9, 'MT'),
(17, 'Monaragala', 7, 'UP'),
(18, 'Mullaitivu', 4, 'ML'),
(19, 'Nuwaraeliy', 1, 'Central'),
(20, 'Polonnaruwa', 3, 'PL'),
(21, 'Puttalam', 5, 'PT'),
(22, 'Rathnapura', 6, 'RT');

-- --------------------------------------------------------

--
-- Table structure for table `farmer`
--

CREATE TABLE `farmer` (
  `fid` int(11) NOT NULL,
  `sno` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `fullname` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `street` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `rupdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `photo` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `mobileNumber` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `statuse` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `numOfcow` int(11) DEFAULT NULL,
  `dateofreg` date DEFAULT NULL,
  `gender` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `pid` int(11) NOT NULL,
  `did` int(11) NOT NULL,
  `aid` int(11) NOT NULL,
  `ftid` int(11) NOT NULL,
  `fmsid` int(11) NOT NULL,
  `regid` int(11) NOT NULL,
  `mccid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `farmer`
--

INSERT INTO `farmer` (`fid`, `sno`, `fullname`, `street`, `rupdate`, `photo`, `mobileNumber`, `statuse`, `numOfcow`, `dateofreg`, `gender`, `dob`, `pid`, `did`, `aid`, `ftid`, `fmsid`, `regid`, `mccid`) VALUES
(4, 'noranukahtes123', 'muthu', 'zxcasds', '2022-10-15 06:00:50', NULL, '789456', 'Death', 16, '2022-09-15', 'male', '1992-11-17', 3, 2, 1, 3, 1, 2, 2),
(6, 'noranukahtes321', 'isuru', 'asdss', '2022-09-17 02:02:53', NULL, '789456', 'Resign', 12, '2022-09-30', 'male', '2022-09-01', 3, 2, 1, 3, 1, 2, 2),
(9, 'noranukahtes321', 'cnoranukahtes1234', '', '2022-10-13 03:20:28', NULL, '', '1', 0, '0000-00-00', 'female', '2022-10-14', 1, 0, 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `farmer_type`
--

CREATE TABLE `farmer_type` (
  `ftid` int(11) NOT NULL,
  `farmerType` varchar(45) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `farmer_type`
--

INSERT INTO `farmer_type` (`ftid`, `farmerType`) VALUES
(1, 'Mega Farmer'),
(2, '900'),
(3, 'FMS');

-- --------------------------------------------------------

--
-- Table structure for table `feed`
--

CREATE TABLE `feed` (
  `feedid` int(11) NOT NULL,
  `regno` varchar(20) COLLATE utf8_bin NOT NULL,
  `date` date NOT NULL,
  `remark` varchar(255) COLLATE utf8_bin NOT NULL,
  `food` varchar(25) COLLATE utf8_bin NOT NULL,
  `quality` varchar(25) COLLATE utf8_bin NOT NULL,
  `feedtime` time NOT NULL,
  `aid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `feed`
--

INSERT INTO `feed` (`feedid`, `regno`, `date`, `remark`, `food`, `quality`, `feedtime`, `aid`) VALUES
(2, 'cnoranukahtes123', '2022-10-12', 'nothing', 'grass', 'good', '16:04:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `fms`
--

CREATE TABLE `fms` (
  `fmsid` int(11) NOT NULL,
  `fmsname` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `fmsnum` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `shortcode` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `mccid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `fms`
--

INSERT INTO `fms` (`fmsid`, `fmsname`, `fmsnum`, `shortcode`, `mccid`) VALUES
(1, 'test', 'NOANKASUTES123', 'TES', 2);

-- --------------------------------------------------------

--
-- Table structure for table `mcc`
--

CREATE TABLE `mcc` (
  `mccid` int(11) NOT NULL,
  `name` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `shortcode` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `mcccode` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `regid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `mcc`
--

INSERT INTO `mcc` (`mccid`, `name`, `shortcode`, `mcccode`, `regid`) VALUES
(2, 'suriya', 'sur', 'kahsur', 2);

-- --------------------------------------------------------

--
-- Table structure for table `milk`
--

CREATE TABLE `milk` (
  `mid` int(11) NOT NULL,
  `fat` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `snf` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `unit` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `date` date DEFAULT NULL,
  `cid` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `aid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `milk`
--

INSERT INTO `milk` (`mid`, `fat`, `snf`, `unit`, `date`, `cid`, `fid`, `qty`, `aid`) VALUES
(4, '14.25', '12.5', 'Kgs', '2022-10-21', 1, 6, 10, 1),
(6, '13.5', '14.5', 'LTRs', '2022-10-20', 1, 4, 25, 1);

-- --------------------------------------------------------

--
-- Table structure for table `province`
--

CREATE TABLE `province` (
  `pid` int(11) NOT NULL,
  `province` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `shortcode` varchar(45) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `province`
--

INSERT INTO `province` (`pid`, `province`, `shortcode`) VALUES
(1, 'Central', 'CP'),
(2, 'Eastern', 'EP'),
(3, 'North Central', 'NC'),
(4, 'Northern', 'NP'),
(5, 'North Western', 'NW'),
(6, 'Sabaragamuwa', 'SG'),
(7, 'Uva', 'UP'),
(8, 'Western', 'WP'),
(9, 'Southern', 'SP');

-- --------------------------------------------------------

--
-- Table structure for table `regional`
--

CREATE TABLE `regional` (
  `regid` int(11) NOT NULL,
  `regional` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `shortcode` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `did` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `regional`
--

INSERT INTO `regional` (`regid`, `regional`, `shortcode`, `did`) VALUES
(2, 'Kahatagasdigiliya', 'KAH', 2);

-- --------------------------------------------------------

--
-- Table structure for table `resit`
--

CREATE TABLE `resit` (
  `rid` int(11) NOT NULL,
  `resitno` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `date` date DEFAULT NULL,
  `fid` int(11) NOT NULL,
  `mid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `usertype`
--

CREATE TABLE `usertype` (
  `utid` int(11) NOT NULL,
  `user_type` varchar(45) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `vaccine`
--

CREATE TABLE `vaccine` (
  `vid` int(11) NOT NULL,
  `regno` varchar(50) COLLATE utf8_bin NOT NULL,
  `date` date NOT NULL,
  `remark` varchar(255) COLLATE utf8_bin NOT NULL,
  `aid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `vaccine`
--

INSERT INTO `vaccine` (`vid`, `regno`, `date`, `remark`, `aid`) VALUES
(5, 'cnoranukahtes123', '2022-10-01', 'test15', 1),
(6, 'cnoranukahtes123', '2022-10-01', 'nothing', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`ccid`);

--
-- Indexes for table `cow`
--
ALTER TABLE `cow`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `distric`
--
ALTER TABLE `distric`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `farmer`
--
ALTER TABLE `farmer`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `farmer_type`
--
ALTER TABLE `farmer_type`
  ADD PRIMARY KEY (`ftid`);

--
-- Indexes for table `feed`
--
ALTER TABLE `feed`
  ADD PRIMARY KEY (`feedid`);

--
-- Indexes for table `fms`
--
ALTER TABLE `fms`
  ADD PRIMARY KEY (`fmsid`);

--
-- Indexes for table `mcc`
--
ALTER TABLE `mcc`
  ADD PRIMARY KEY (`mccid`);

--
-- Indexes for table `milk`
--
ALTER TABLE `milk`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `province`
--
ALTER TABLE `province`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `regional`
--
ALTER TABLE `regional`
  ADD PRIMARY KEY (`regid`);

--
-- Indexes for table `resit`
--
ALTER TABLE `resit`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `usertype`
--
ALTER TABLE `usertype`
  ADD PRIMARY KEY (`utid`);

--
-- Indexes for table `vaccine`
--
ALTER TABLE `vaccine`
  ADD PRIMARY KEY (`vid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `ccid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cow`
--
ALTER TABLE `cow`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `distric`
--
ALTER TABLE `distric`
  MODIFY `did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `farmer`
--
ALTER TABLE `farmer`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `farmer_type`
--
ALTER TABLE `farmer_type`
  MODIFY `ftid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `feed`
--
ALTER TABLE `feed`
  MODIFY `feedid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fms`
--
ALTER TABLE `fms`
  MODIFY `fmsid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mcc`
--
ALTER TABLE `mcc`
  MODIFY `mccid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `milk`
--
ALTER TABLE `milk`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `province`
--
ALTER TABLE `province`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `regional`
--
ALTER TABLE `regional`
  MODIFY `regid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `resit`
--
ALTER TABLE `resit`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usertype`
--
ALTER TABLE `usertype`
  MODIFY `utid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vaccine`
--
ALTER TABLE `vaccine`
  MODIFY `vid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
